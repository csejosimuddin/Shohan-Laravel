-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2021 at 02:33 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `josim`
--

-- --------------------------------------------------------

--
-- Table structure for table `billing_infos`
--

CREATE TABLE `billing_infos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip_code` int(11) NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `billing_infos`
--

INSERT INTO `billing_infos` (`id`, `order_id`, `full_name`, `company`, `address`, `zip_code`, `phone_number`, `email_address`, `country_id`, `city_id`, `created_at`, `updated_at`) VALUES
(2, 3, 'ma', 'Cse', 'Cse', 600, '01516166907', 'ma@gmail.com', 3, 1, '2021-06-29 12:07:42', NULL),
(3, 4, 'ma', 'Cse', 'Cse', 600, '01516166907', 'ma@gmail.com', 5, 18, '2021-06-30 10:13:06', NULL),
(4, 5, 'ma', 'Cse', 'Cse', 600, '01516166907', 'ma@gmail.com', 5, 22, '2021-06-30 11:25:49', NULL),
(5, 6, 'ma', 'Cse', 'Cse', 600, '01516166907', 'ma@gmail.com', 2, 40, '2021-06-30 11:30:13', NULL),
(6, 7, 'ma', 'Cse', 'Cse', 600, '01516166907', 'ma@gmail.com', 2, 40, '2021-06-30 11:31:06', NULL),
(7, 8, 'ma', 'Cse', 'Cse', 600, '01516166907', 'ma@gmail.com', 2, 40, '2021-07-02 06:28:52', NULL),
(8, 9, 'ma', 'Cse', 'Cse', 600, '01516166907', 'ma@gmail.com', 5, 18, '2021-07-02 06:29:48', NULL),
(9, 10, 'ma', 'Cse', 'Cse', 600, '01516166907', 'ma@gmail.com', 5, 18, '2021-07-02 06:30:32', NULL),
(10, 11, 'ma', 'Cse', 'Cse', 600, '01516166907', 'ma@gmail.com', 5, 18, '2021-07-02 06:30:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `customer_ip`, `product_id`, `product_quantity`, `created_at`, `updated_at`) VALUES
(12, '127.152.0.1', 1, 1, '2021-06-07 23:55:35', '2021-06-09 03:11:23');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_id`, `menu_status`, `created_at`, `updated_at`) VALUES
(1, 'man', 1, '2021-05-29 03:14:52', '2021-06-03 21:55:54'),
(2, 'Woman', 0, '2021-05-29 03:16:28', '2021-06-03 21:55:59'),
(3, 'child', 0, '2021-05-29 03:17:10', '2021-06-03 21:56:11'),
(4, 'App Development', 0, '2021-05-29 10:40:36', NULL),
(5, 'josim', 0, '2021-05-30 18:39:32', '2021-06-14 21:56:10'),
(6, 'Laravel', 0, '2021-05-30 18:46:39', '2021-05-30 13:17:05'),
(7, 'SPC', 1, '2021-06-04 05:11:50', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `first_name`, `last_name`, `subject`, `message`, `read_status`, `created_at`, `updated_at`) VALUES
(1, 'first', 'secend', 'valo', 'valo', 1, NULL, NULL),
(2, 'MD. RAKIBUL ISLAM', 'Sattar', 'SSL/TSL Renew', 'SSL/TSL Renew SSL/TSL Renew SSL/TSL Renew', 1, NULL, NULL),
(3, 'MD. AL AMIN', 'Rahaman', '<div class=\"alert alert-success\">', '<div class=\"<div class=\"alert alert-success\">alert alert-success\">', 1, NULL, NULL),
(4, 'MD. RAKIBUL ISLAM', 'Sattar', 'SSL/TSL Renew', 'SSL/TSL Renew', 1, NULL, NULL),
(5, 'MD. RAKIBUL ISLAM', 'Sattar', 'SSL/TSL Renew', 'Hello', 1, NULL, NULL),
(6, 'MD. RAKIBUL ISLAM', 'Sattar', 'SSL/TSL Renew', 'Hello', 1, NULL, NULL),
(7, 'MD. RAKIBUL ISLAM', 'Sattar', 'SSL/TSL Renew', 'Hello', 1, NULL, NULL),
(8, 'MD. AL AMIN', 'Sattar', 'SSL/TSL Renew', 'Josim', 1, NULL, NULL),
(9, 'SARROWER ZAHAN SOJIB', 'mahi', 'Vai', 'Secend Message', 1, NULL, NULL),
(10, 'MD. RAKIBUL ISLAM', 'Sattar', 'Vai', 'I Am Your Message!!', 1, NULL, NULL),
(11, 'MD. RAKIBUL ISLAM', 'Sattar', 'Vai', 'I Am Your Message!!', 1, NULL, NULL),
(12, 'f', 'f', 'f', 'ffff', 1, NULL, NULL),
(13, 'f', 'f', 'f', 'ffff', 1, NULL, NULL),
(14, 'f', 'f', 'f', 'ffffbb', 1, NULL, NULL),
(15, 'q', 'q', 'q', 'aaa', 1, NULL, NULL),
(16, 'MD. AZAD RAHMAN LIKHON', 'Babu', 'SSL/TSL Renew', 'Ami course korte chai', 2, NULL, '2021-06-03 23:09:44'),
(17, 'SHIMUL PARVEZ', 'Rahaman', 'SSL/TSL Renew', 'xvxnbhjbdf', 2, NULL, NULL),
(18, 'scc', 'scasc', 'ascas', 'asxasc', 2, NULL, '2021-06-03 23:08:40'),
(19, 'xx', 'xx', 'xx', 'xxx', 2, NULL, '2021-06-03 23:09:35'),
(20, 's', 's', 's', 's', 2, NULL, '2021-06-03 23:09:41'),
(21, 'মো:জসিম উদ্দীন', 'সরকার', 'ওয়েব ডিজাইন', 'আমি এই কোর্সটি করতে আগ্রহী ০১৭২২৮৫৮৬৭৭', 2, NULL, '2021-06-06 03:09:55');

-- --------------------------------------------------------

--
-- Table structure for table `coupon`
--

CREATE TABLE `coupon` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `coupon_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coupon_percentage` int(11) NOT NULL,
  `valid_till` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupon`
--

INSERT INTO `coupon` (`id`, `coupon_name`, `coupon_percentage`, `valid_till`, `created_at`, `updated_at`) VALUES
(1, 'EID20', 15, '2021-06-28 18:00:00', '2021-06-23 18:02:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customerprofile`
--

CREATE TABLE `customerprofile` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `Company` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `ZipCode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `PhoneNumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customerprofile`
--

INSERT INTO `customerprofile` (`id`, `user_id`, `Company`, `address`, `ZipCode`, `PhoneNumber`, `created_at`, `updated_at`) VALUES
(4, 9, 'জসিম উদ্দীন', 'বাংলাদেশ', '1206', '01722858677', '2021-06-19 11:21:00', '2021-06-19 11:21:00'),
(5, 8, 'জসিম ভাই', 'জসিম ভাইজসিম ভাইজসিম ভাইজসিম ভাই', '1751', '01785686574', '2021-06-19 11:32:17', '2021-06-19 11:32:17'),
(6, 2, 'josim Uddin', 'Luxmipur Rajshahi', '6000', '01722858677', '2021-06-28 09:21:47', NULL),
(7, 3, 'Cse', 'Cse', '600', '01516166907', '2021-06-29 11:20:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` int(2) UNSIGNED NOT NULL,
  `division_id` int(2) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `bn_name` varchar(50) NOT NULL,
  `lat` double NOT NULL,
  `lon` double NOT NULL,
  `website` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `division_id`, `name`, `bn_name`, `lat`, `lon`, `website`) VALUES
(1, 3, 'Dhaka', 'ঢাকা', 23.7115253, 90.4111451, 'www.dhaka.gov.bd'),
(2, 3, 'Faridpur', 'ফরিদপুর', 23.6070822, 89.8429406, 'www.faridpur.gov.bd'),
(3, 3, 'Gazipur', 'গাজীপুর', 24.0022858, 90.4264283, 'www.gazipur.gov.bd'),
(4, 3, 'Gopalganj', 'গোপালগঞ্জ', 23.0050857, 89.8266059, 'www.gopalganj.gov.bd'),
(5, 3, 'Jamalpur', 'জামালপুর', 24.937533, 89.937775, 'www.jamalpur.gov.bd'),
(6, 3, 'Kishoreganj', 'কিশোরগঞ্জ', 24.444937, 90.776575, 'www.kishoreganj.gov.bd'),
(7, 3, 'Madaripur', 'মাদারীপুর', 23.164102, 90.1896805, 'www.madaripur.gov.bd'),
(8, 3, 'Manikganj', 'মানিকগঞ্জ', 0, 0, 'www.manikganj.gov.bd'),
(9, 3, 'Munshiganj', 'মুন্সিগঞ্জ', 0, 0, 'www.munshiganj.gov.bd'),
(10, 3, 'Mymensingh', 'ময়মনসিং', 0, 0, 'www.mymensingh.gov.bd'),
(11, 3, 'Narayanganj', 'নারায়াণগঞ্জ', 23.63366, 90.496482, 'www.narayanganj.gov.bd'),
(12, 3, 'Narsingdi', 'নরসিংদী', 23.932233, 90.71541, 'www.narsingdi.gov.bd'),
(13, 3, 'Netrokona', 'নেত্রকোনা', 24.870955, 90.727887, 'www.netrokona.gov.bd'),
(14, 3, 'Rajbari', 'রাজবাড়ি', 23.7574305, 89.6444665, 'www.rajbari.gov.bd'),
(15, 3, 'Shariatpur', 'শরীয়তপুর', 0, 0, 'www.shariatpur.gov.bd'),
(16, 3, 'Sherpur', 'শেরপুর', 25.0204933, 90.0152966, 'www.sherpur.gov.bd'),
(17, 3, 'Tangail', 'টাঙ্গাইল', 0, 0, 'www.tangail.gov.bd'),
(18, 5, 'Bogra', 'বগুড়া', 24.8465228, 89.377755, 'www.bogra.gov.bd'),
(19, 5, 'Joypurhat', 'জয়পুরহাট', 0, 0, 'www.joypurhat.gov.bd'),
(20, 5, 'Naogaon', 'নওগাঁ', 0, 0, 'www.naogaon.gov.bd'),
(21, 5, 'Natore', 'নাটোর', 24.420556, 89.000282, 'www.natore.gov.bd'),
(22, 5, 'Nawabganj', 'নবাবগঞ্জ', 24.5965034, 88.2775122, 'www.chapainawabganj.gov.bd'),
(23, 5, 'Pabna', 'পাবনা', 23.998524, 89.233645, 'www.pabna.gov.bd'),
(24, 5, 'Rajshahi', 'রাজশাহী', 0, 0, 'www.rajshahi.gov.bd'),
(25, 5, 'Sirajgonj', 'সিরাজগঞ্জ', 24.4533978, 89.7006815, 'www.sirajganj.gov.bd'),
(26, 6, 'Dinajpur', 'দিনাজপুর', 25.6217061, 88.6354504, 'www.dinajpur.gov.bd'),
(27, 6, 'Gaibandha', 'গাইবান্ধা', 25.328751, 89.528088, 'www.gaibandha.gov.bd'),
(28, 6, 'Kurigram', 'কুড়িগ্রাম', 25.805445, 89.636174, 'www.kurigram.gov.bd'),
(29, 6, 'Lalmonirhat', 'লালমনিরহাট', 0, 0, 'www.lalmonirhat.gov.bd'),
(30, 6, 'Nilphamari', 'নীলফামারী', 25.931794, 88.856006, 'www.nilphamari.gov.bd'),
(31, 6, 'Panchagarh', 'পঞ্চগড়', 26.3411, 88.5541606, 'www.panchagarh.gov.bd'),
(32, 6, 'Rangpur', 'রংপুর', 25.7558096, 89.244462, 'www.rangpur.gov.bd'),
(33, 6, 'Thakurgaon', 'ঠাকুরগাঁও', 26.0336945, 88.4616834, 'www.thakurgaon.gov.bd'),
(34, 1, 'Barguna', 'বরগুনা', 0, 0, 'www.barguna.gov.bd'),
(35, 1, 'Barisal', 'বরিশাল', 0, 0, 'www.barisal.gov.bd'),
(36, 1, 'Bhola', 'ভোলা', 22.685923, 90.648179, 'www.bhola.gov.bd'),
(37, 1, 'Jhalokati', 'ঝালকাঠি', 0, 0, 'www.jhalakathi.gov.bd'),
(38, 1, 'Patuakhali', 'পটুয়াখালী', 22.3596316, 90.3298712, 'www.patuakhali.gov.bd'),
(39, 1, 'Pirojpur', 'পিরোজপুর', 0, 0, 'www.pirojpur.gov.bd'),
(40, 2, 'Bandarban', 'বান্দরবান', 22.1953275, 92.2183773, 'www.bandarban.gov.bd'),
(41, 2, 'Brahmanbaria', 'ব্রাহ্মণবাড়িয়া', 23.9570904, 91.1119286, 'www.brahmanbaria.gov.bd'),
(42, 2, 'Chandpur', 'চাঁদপুর', 23.2332585, 90.6712912, 'www.chandpur.gov.bd'),
(43, 2, 'Chittagong', 'চট্টগ্রাম', 22.335109, 91.834073, 'www.chittagong.gov.bd'),
(44, 2, 'Comilla', 'কুমিল্লা', 23.4682747, 91.1788135, 'www.comilla.gov.bd'),
(45, 2, 'Cox\'s Bazar', 'কক্স বাজার', 0, 0, 'www.coxsbazar.gov.bd'),
(46, 2, 'Feni', 'ফেনী', 23.023231, 91.3840844, 'www.feni.gov.bd'),
(47, 2, 'Khagrachari', 'খাগড়াছড়ি', 23.119285, 91.984663, 'www.khagrachhari.gov.bd'),
(48, 2, 'Lakshmipur', 'লক্ষ্মীপুর', 22.942477, 90.841184, 'www.lakshmipur.gov.bd'),
(49, 2, 'Noakhali', 'নোয়াখালী', 22.869563, 91.099398, 'www.noakhali.gov.bd'),
(50, 2, 'Rangamati', 'রাঙ্গামাটি', 0, 0, 'www.rangamati.gov.bd'),
(51, 7, 'Habiganj', 'হবিগঞ্জ', 24.374945, 91.41553, 'www.habiganj.gov.bd'),
(52, 7, 'Maulvibazar', 'মৌলভীবাজার', 24.482934, 91.777417, 'www.moulvibazar.gov.bd'),
(53, 7, 'Sunamganj', 'সুনামগঞ্জ', 25.0658042, 91.3950115, 'www.sunamganj.gov.bd'),
(54, 7, 'Sylhet', 'সিলেট', 24.8897956, 91.8697894, 'www.sylhet.gov.bd'),
(55, 4, 'Bagerhat', 'বাগেরহাট', 22.651568, 89.785938, 'www.bagerhat.gov.bd'),
(56, 4, 'Chuadanga', 'চুয়াডাঙ্গা', 23.6401961, 88.841841, 'www.chuadanga.gov.bd'),
(57, 4, 'Jessore', 'যশোর', 23.16643, 89.2081126, 'www.jessore.gov.bd'),
(58, 4, 'Jhenaidah', 'ঝিনাইদহ', 23.5448176, 89.1539213, 'www.jhenaidah.gov.bd'),
(59, 4, 'Khulna', 'খুলনা', 22.815774, 89.568679, 'www.khulna.gov.bd'),
(60, 4, 'Kushtia', 'কুষ্টিয়া', 23.901258, 89.120482, 'www.kushtia.gov.bd'),
(61, 4, 'Magura', 'মাগুরা', 23.487337, 89.419956, 'www.magura.gov.bd'),
(62, 4, 'Meherpur', 'মেহেরপুর', 23.762213, 88.631821, 'www.meherpur.gov.bd'),
(63, 4, 'Narail', 'নড়াইল', 23.172534, 89.512672, 'www.narail.gov.bd'),
(64, 4, 'Satkhira', 'সাতক্ষীরা', 0, 0, 'www.satkhira.gov.bd');

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

CREATE TABLE `divisions` (
  `id` int(2) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `bn_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`id`, `name`, `bn_name`) VALUES
(1, 'Barisal', 'বরিশাল'),
(2, 'Chittagong', 'চট্টগ্রাম'),
(3, 'Dhaka', 'ঢাকা'),
(4, 'Khulna', 'খুলনা'),
(5, 'Rajshahi', 'রাজশাহী'),
(6, 'Rangpur', 'রংপুর'),
(7, 'Sylhet', 'সিলেট');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2021_05_29_030841_categories', 3),
(7, '2021_05_29_041450_product', 4),
(8, '2021_06_03_102643_contact', 5),
(9, '2021_06_07_043343_cart_migration', 6),
(10, '2021_06_10_233628_coupon', 7),
(11, '2021_06_19_104527_customerprofile', 8),
(12, '2021_06_24_031703_order_info', 9),
(13, '2021_06_24_032612_billing_info', 10),
(14, '2021_06_24_041207_order_info', 11),
(16, '2021_06_24_091248_billinginfo', 12),
(17, '2021_06_24_093231_billinginfo', 13),
(18, '2021_06_24_171640_create_billing_infos_table', 14),
(19, '2021_06_24_172724_create_orders_table', 14),
(20, '2021_06_25_045941_create_order_histories_table', 15),
(21, '2021_07_02_094312_create_reviews_table', 16);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) NOT NULL,
  `Subtotal` int(11) NOT NULL,
  `Shipping` int(11) NOT NULL,
  `cupon_discount` int(11) NOT NULL,
  `total_amount_show` int(11) NOT NULL,
  `payment_type` int(11) NOT NULL,
  `payment_status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `Subtotal`, `Shipping`, `cupon_discount`, `total_amount_show`, `payment_type`, `payment_status`, `created_at`, `updated_at`) VALUES
(3, 3, 120, 0, 0, 120, 1, 1, '2021-06-29 12:07:42', NULL),
(4, 3, 1550, 5, 0, 1555, 2, 2, '2021-06-30 10:13:06', NULL),
(5, 3, 605, 5, 0, 610, 2, 2, '2021-06-30 11:25:49', '2021-06-30 11:27:24'),
(6, 3, 45, 5, 0, 50, 2, 2, '2021-06-30 11:30:13', '2021-06-30 11:30:39'),
(7, 3, 45, 5, 0, 50, 1, 1, '2021-06-30 11:31:05', NULL),
(8, 3, 400, 5, 0, 405, 1, 1, '2021-07-02 06:28:52', NULL),
(9, 3, 400, 5, 0, 405, 1, 1, '2021-07-02 06:29:48', NULL),
(10, 3, 100, 5, 0, 105, 1, 1, '2021-07-02 06:30:32', NULL),
(11, 3, 100, 5, 0, 105, 1, 1, '2021-07-02 06:30:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_histories`
--

CREATE TABLE `order_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `Product_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Product_Price` int(11) NOT NULL,
  `Product_Quentity` int(11) NOT NULL,
  `total_price` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_histories`
--

INSERT INTO `order_histories` (`id`, `order_id`, `product_id`, `Product_Name`, `Product_Price`, `Product_Quentity`, `total_price`, `created_at`, `updated_at`) VALUES
(1, 3, 3, 'child', 120, 1, 120, '2021-06-29 12:07:42', NULL),
(2, 4, 1, 'cit', 1550, 1, 1550, '2021-06-30 10:13:06', NULL),
(3, 5, 2, 'cit', 15, 3, 45, '2021-06-30 11:25:49', NULL),
(4, 5, 3, 'child', 120, 3, 360, '2021-06-30 11:25:49', NULL),
(5, 5, 5, 'child', 100, 2, 200, '2021-06-30 11:25:49', NULL),
(6, 6, 2, 'cit', 15, 3, 45, '2021-06-30 11:30:13', NULL),
(7, 7, 2, 'cit', 15, 3, 45, '2021-06-30 11:31:06', NULL),
(8, 8, 7, 'josim22', 100, 4, 400, '2021-07-02 06:28:52', NULL),
(9, 10, 7, 'josim22', 100, 1, 100, '2021-07-02 06:30:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_p_id` int(11) NOT NULL,
  `Product_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Product_Description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Product_Price` int(11) NOT NULL,
  `Product_Quentity` int(11) NOT NULL,
  `Product_Alert_Quentity` int(11) NOT NULL,
  `Product_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'defaultproductphoto.jpg',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_p_id`, `Product_Name`, `Product_Description`, `Product_Price`, `Product_Quentity`, `Product_Alert_Quentity`, `Product_image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 2, 'cit', 'scc', 1550, 100, 1, 'defaultproductphoto.jpg', NULL, NULL, NULL),
(2, 1, 'cit', 'bh', 15, 15, 1, 'defaultproductphoto.jpg', NULL, NULL, NULL),
(3, 3, 'child', 'chilaa', 120, 14, 1, 'defaultproductphoto.jpg', NULL, NULL, NULL),
(4, 4, 'App Development', 'App Development App DevelopmentApp Development App DevelopmentApp Development', 2, 14, 5, '4.jpg', NULL, '2021-05-29 04:41:17', NULL),
(5, 3, 'child', 'childchildchild', 100, 25478, 5, 'defaultproductphoto.jpg', NULL, NULL, NULL),
(6, 6, 'ল্যারাভেল', 'ল্যারাভেলল্যারাভেলল্যারাভেলল্যারাভেল', 15, 21, 15, 'defaultproductphoto.jpg', NULL, NULL, NULL),
(7, 5, 'josim22', 'josim22josim22josim22josim22josim22', 100, 15, 2, 'defaultproductphoto.jpg', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_history_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `Comment` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `points` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `order_history_id`, `product_id`, `Comment`, `points`, `created_at`, `updated_at`) VALUES
(1, 3, 2, 'product valo', 5, NULL, NULL),
(2, 9, 7, 'cm, njkn', 5, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(2) NOT NULL DEFAULT 1,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `role`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@gmail.com', '01516166907', 1, NULL, '$2y$10$9D.XrJZZyHpGT79niQ/GKen0JLx0OvqCXcWJTvSSY7rxHGaVimCFq', 'E5OQE44fSYXuxDHUK66mOFls3rEXuUdNaOd7DaUB4ikDcAbtDsQGa81jekgP', '2021-06-28 07:31:43', '2021-06-28 07:31:43'),
(2, 'josimUddin', 'josimuddin228586@gmail.com', '01722858677', 2, NULL, '$2y$10$yisJaL9yY9CG5Bl97T3kN.U.iqHmFx7/fDT/.JPbKWWvNP5fmbJ26', NULL, '2021-06-28 09:20:45', NULL),
(3, 'ma', 'ma@gmail.com', '01516166909', 2, NULL, '$2y$10$/A6cY9e0A1Acgl5YcnV.uOpAib.kCI0PpbtpObdikefJFaaogIU.e', NULL, '2021-06-29 11:10:30', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billing_infos`
--
ALTER TABLE `billing_infos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupon`
--
ALTER TABLE `coupon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customerprofile`
--
ALTER TABLE `customerprofile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `division_id` (`division_id`);

--
-- Indexes for table `divisions`
--
ALTER TABLE `divisions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_histories`
--
ALTER TABLE `order_histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billing_infos`
--
ALTER TABLE `billing_infos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `coupon`
--
ALTER TABLE `coupon`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customerprofile`
--
ALTER TABLE `customerprofile`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `id` int(2) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `divisions`
--
ALTER TABLE `divisions`
  MODIFY `id` int(2) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `order_histories`
--
ALTER TABLE `order_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `districts`
--
ALTER TABLE `districts`
  ADD CONSTRAINT `districts_ibfk_1` FOREIGN KEY (`division_id`) REFERENCES `divisions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
