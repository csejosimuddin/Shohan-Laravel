<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\CouponModel;
use Carbon\Carbon;

class CouponController extends Controller
{
  function couponview(){
      $coupon_Show = CouponModel::all();
    return view('product.coupon.view', compact('coupon_Show'));
  }

// Add Coupon

function addcoupon(Request $request){
    $request->validate([
        'coupon_name' => 'required|unique:coupon,coupon_name',
        'Coupon_Percentage' => 'required|numeric|min:1|max:99',
    ]);

    if($request->Valid_Till <= Carbon::now()->format('d-m-Y')){

        CouponModel::insert([
            'coupon_name' => $request->coupon_name,
            'Coupon_Percentage' => $request->Coupon_Percentage,
            'Valid_Till' => $request->Valid_Till,
            'created_at' => Carbon::now('Asia/Dhaka')
        ]);
        return back();
    }
    else{
        return back()->withErrors('Date is not Correct!');
    }
  
    

}


}
