<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Stripe;
use App\order;
   
class StripePaymentController extends Controller
{
   public function stripe()
    {
        return view('frontend.Credit_card.Stripe');
    }

    public function stripePost(Request $request)
    {
        Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
        Stripe\Charge::create ([
                "amount" => 100 * $request->total_amount_show,
                "currency" => "usd",
                "source" => $request->stripeToken,
                "description" => "Test payment from itsolutionstuff.com." 
        ]);
        order::find($request->order_id)->update([
        	'payment_status' => 2
        ]);
        echo "Payment successful!";

        // Session::flash('success', 'Payment successful!');
          
        // return back();
    }
}