<?php

namespace App\Http\Controllers;
use App\CartModel;
use Carbon\Carbon;
use App\productModel;
use App\CouponModel;

use Illuminate\Http\Request;

class Cartcontroller extends Controller
{
   function addtocart($product_id){
$customer_ip = $_SERVER['REMOTE_ADDR'];

if(CartModel::where('customer_ip', $customer_ip)->where('product_id', $product_id )->exists()){

   CartModel::where('customer_ip', $customer_ip)->where('product_id', $product_id )->increment('product_quantity', 1);
}
else{
  CartModel::insert([
'product_id'=> $product_id,
'customer_ip'=> $customer_ip,
'created_at'=> Carbon::now()
]);

}
return back();


   }


// Cart View
function CartView($Coupon_name = " "){
if($Coupon_name != " "){
   
if(CouponModel::where('coupon_name', $Coupon_name)->exists()){

   if(carbon::now()->format('Y-m-d') <= carbon::create(CouponModel::where('coupon_name', $Coupon_name)->first()->valid_till)->format('Y-m-d')){
      $copuen_percentage = CouponModel::where('coupon_name', $Coupon_name)->first()->coupon_percentage;
      $CartallProduct = CartModel::where('customer_ip',$_SERVER["REMOTE_ADDR"])->get();
      return view('frontend.CartView', compact('CartallProduct','copuen_percentage','Coupon_name'));
   }
   else{
      echo"Date Valide Nai";
   }
   }
   else{
      echo "Coupon Nai";
   }

}
else{
   $copuen_percentage = 0;
   $CartallProduct = CartModel::where('customer_ip',$_SERVER["REMOTE_ADDR"])->get();
      return view('frontend.CartView', compact('CartallProduct','copuen_percentage','Coupon_name'));

}



}




function CartDelete($product_id){
   CartModel::where('customer_ip', $_SERVER['REMOTE_ADDR'])->where('id', $product_id )->delete();
   return back();
}


function Cartclear(){
   CartModel::where('customer_ip', $_SERVER['REMOTE_ADDR'])->delete();
   return back();
}

function updatecart(Request $request){
 
foreach($request->product_id as $product_id_key => $product_id_value){
echo $product_id_value."<br>";
echo $request->product_quantity[$product_id_key]."<br>";

if($request->product_quantity[$product_id_key] > 0){
  if($request->product_quantity[$product_id_key] <= productModel::find($product_id_value)->Product_Quentity){
   CartModel::where('customer_ip', $_SERVER['REMOTE_ADDR'])->where('product_id', $product_id_value)->update([
      'product_quantity' => $request->product_quantity[$product_id_key]
   ]);
  }
  else{
   echo "Product Not Available";
}

}

else{
   echo"0 dicen kno?";
}

}

return back();

}



}