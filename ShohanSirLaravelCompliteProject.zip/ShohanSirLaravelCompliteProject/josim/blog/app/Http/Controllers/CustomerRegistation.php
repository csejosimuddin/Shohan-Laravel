<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\order;
use App\order_history;
use Carbon\Carbon;
use App\review;
use Hash;
use Auth;

class CustomerRegistation extends Controller
{
    function Customerregistationview(){
        return view('frontend.CustomerReg.Customerregistation');
    }


    function CustomerRegister(Request $request){

        $request->validate([
            'name' => 'required',
            'password' => 'required|min:8',
            'password_confirmation' => 'required',
            'password_confirmation' => 'same:password'
        
            ]);

        User::insert([
            'name' => $request->name,
            'email' => $request->email,
            'username' => $request->username,
            'role' => 2,
            'password' => bcrypt($request->password),
            'created_at' => Carbon::now()
       
            ]);
            return back();

    }

    function customerDashboird(){
        $order = order::where('user_id', Auth::id())->get();
        return view('frontend.CustDash.view', compact('order'));
    }






    // ChangeSetPassword

    function ChangeSetPassword(){

        return view('frontend.CustDash.passwordChange');
    }


    function Changepassword(Request $request){
	
        if(Hash::check($request->oldpassword, Auth::user()->password)){
            $request->validate([
            'newpassword' => 'required|min:8',
            'confirmpassword' => 'required',
            'confirmpassword' => 'same:newpassword'
        
            ]);
        User::find(Auth::id())->update([
        'password' => bcrypt($request->newpassword)
        ]);
        
        echo "New Password Set!";
        }
        
        
        else{
            echo "mile nai";
        }
        
        
        }


        // customerprofile

        
    // OrderDetails এর সবার পরে
    function orderdetails($order_id){
        $order_history = order_history::where('order_id', $order_id)->get();
        return view('frontend.CustDash.orderdetails', compact('order_history'));
    }

    // Customer review Option Controller
    function submitreview($order_history_id){
        $product_id = order_history::find($order_history_id)->product_id;
      return view('frontend.CustDash.review', compact('order_history_id', 'product_id'));
    }

        function submitreviewinsert(Request $request){
            review::insert($request->except('_token'));
            echo "Done";
        }



}
