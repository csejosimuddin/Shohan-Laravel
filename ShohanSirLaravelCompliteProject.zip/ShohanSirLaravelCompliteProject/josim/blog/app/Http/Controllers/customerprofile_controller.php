<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\customerprofile;
use Auth;
use Carbon\Carbon;


class customerprofile_controller extends Controller
{
    function customerprofile(){
      return view('frontend.customerprofile.customerprofile');
    }


    function myprofileinsert(Request $request){
        customerprofile::insert($request->except('_token')+ [
            'user_id' => Auth::id(),
            'created_at' => Carbon::now()
        
            ]); 
        
            return back();
    }


    function myprofileupdate(Request $request){
      customerprofile::where('user_id', Auth::id())->update([
        'Company' => $request->Company,
        'address' => $request->address,
        'ZipCode' => $request->ZipCode,
        'PhoneNumber' => $request->PhoneNumber,
        'created_at' => Carbon::now()
      ]);

      return back()->with('myprofileupdate', 'Profile Update SuccessFully!');
    }



}
