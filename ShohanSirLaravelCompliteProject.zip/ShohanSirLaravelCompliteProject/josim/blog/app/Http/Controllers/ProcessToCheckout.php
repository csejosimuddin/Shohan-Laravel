<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\customerprofile;
use App\districtsmodel;
use App\divisionsmodel;
use App\Billing_info;
use App\order;
use App\CartModel;
use App\order_history;
use App\productModel;
use Carbon\Carbon;
use Auth;
class ProcessToCheckout extends Controller
{
   function ProcessToCheckout(Request $request){
      $divisionsmodel = divisionsmodel::all();
      $districtsmodel = districtsmodel::all();
      $customer_profile = customerprofile::where('user_id', Auth::id())->first();
      $Subtotal = $request->Subtotal;
      $Shipping = $request->Shipping;
      $cupon_discount = $request->cupon_discount;
    $total_amount_show = $request->total_amount_show;
   return view('frontend.procestocheckout', compact('customer_profile','cupon_discount','Shipping','Subtotal','total_amount_show','divisionsmodel'));
   }


   function getdistricts(Request $request){
      $string_to_send = "";
     $districts = districtsmodel::where('division_id', $request->division_id)->get();
     foreach($districts as $district){
     $string_to_send .= "<option value='".$district->id."'>".$district->name."</option>";
   }
   echo $string_to_send;
   }

// Place Order a Click করলে যা হবে
function checkoutsubmit(Request $request){

   // print_r($request->all());

   $order_id = order::insertGetId([
      'user_id' => Auth::id(),
      'Subtotal' => $request->Subtotal,
      'Shipping' => $request->Shipping,
      'cupon_discount' => $request->cupon_discount,
      'total_amount_show' => $request->total_amount_show,
      'payment_type' => $request->payment_type,
      'payment_status' => 1,
      'created_at' => Carbon::now()
   ]);

   Billing_info::insert([
      'order_id' => $order_id,
      'full_name' => $request->full_name,
      'company' => $request->company,
      'address' => $request->address,
      'zip_code' => $request->zip_code,
      'phone_number' => $request->phone_number,
      'email_address' => $request->email_address,
      'country_id' => $request->country_id,
      'city_id' => $request->city_id,
      'created_at' => Carbon::now()
   ]);

   $cart_items = CartModel::where('customer_ip', $_SERVER['REMOTE_ADDR'])->get();
   foreach($cart_items as $cart_item)
   order_history::insert([
      'order_id' => $order_id,
      'product_id' => $cart_item->product_id,
      'Product_Name' => productModel::find($cart_item->product_id)->Product_Name,
      'Product_Price' => productModel::find($cart_item->product_id)->Product_Price,
      'Product_Quentity' => $cart_item->product_quantity,
      'total_price' => (productModel::find($cart_item->product_id)->Product_Price)*($cart_item->product_quantity),
      'created_at' => Carbon::now()
   ]);
   
    

   if( $request->payment_type == 1 ){
      echo "Done Product Buy Successfully";
   }else{
      $total_amount_show = $request->total_amount_show;
      return view('frontend.Credit_card.Stripe', compact('total_amount_show','order_id'));
   }
   $cart_item->delete();
 
}







}
