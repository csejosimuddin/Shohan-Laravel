<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\categories;
use Carbon\Carbon;

class CategoryCongtroller extends Controller
{
    function view(){
        $categories = categories::all();
        return view('product.Category.view',compact('categories'));
    }

    function addcategoryinsert(Request $request){

    $request->validate([
        'category_name' => 'required|unique:categories,category_id'
    
    ]);
if(isset($request->menu_status)){
      categories::insert([
        'category_id' => $request->category_name,
        'menu_status' => true,
        'created_at' => Carbon::now('Asia/Dhaka')
    ]);
}
else{
    categories::insert([
        'category_id' => $request->category_name,
        'menu_status' => false,
        'created_at' => Carbon::now('Asia/Dhaka')
    ]);
}
    
//   categories::insert([
//         'category_id' => $request->category_name,
//         'created_at' => Carbon::now('Asia/Dhaka')
//     ]);


     return back()->with('status', 'Product Insert SuccessFully!');

    }



    // menuChange

function changemenustatus($category_id){

    if(categories::find($category_id)->menu_status == 0){
		categories::find($category_id)->update([
		'menu_status' => true
	
		]);

}
else{
	categories::find($category_id)->update([
		'menu_status' => false
		]);
}
return back();
}

}