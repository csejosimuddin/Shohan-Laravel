<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\productModel;
use App\categories;
use Image;


class ProductCongtroller extends Controller
{

	public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role');
    }


    function index(){
        $all_Products = productModel::orderBy('id','desc')->paginate(4);
        $deteted_product_show = productModel::onlyTrashed()->get();
		$categories = categories::all();
        return view('product.AddNewproduct',compact('all_Products','deteted_product_show','categories'));
    }

    // Product Insert

    function addproductinsert(Request $request){
		$request->validate([
			'categoryselectid' => 'required',
			'Product_Name_josim' => 'required',
			'Product_Description' => 'required',
			'Product_Price' => 'required|numeric',
			'Product_Quentity' => 'required|numeric',
			'Product_Alert_Quentity' => 'required|numeric',
		
		]);

    	$last_inserted_id = productModel::insertGetId([
			'category_p_id' => $request->categoryselectid,
			'Product_Name' => $request->Product_Name_josim,
    		'Product_Description' => $request->Product_Description,
    		'Product_Price' => $request->Product_Price,
    		'Product_Quentity' => $request->Product_Quentity,
    		'Product_Alert_Quentity' => $request->Product_Alert_Quentity,
    	]);

		
    	if($request->hasFile('Product_image')){
    		$photo_to_upload = $request->Product_image;
    		$filename = $last_inserted_id.".".$photo_to_upload->getClientOriginalExtension();
    		Image::make($photo_to_upload)->resize(400,450)->save(base_path('public/uploads/product_photos/'.$filename),85);
    		productModel::find($last_inserted_id)->update([
    			'Product_image' => $filename
    		]);

    	}



			

    	return back();
    }


    // product edite 
    function editproduct($product_id){
		$single_product_info = productModel::findOrFail($product_id);
		return view('Product.productedite', compact('single_product_info'));
	}



    // Edit করে ডাটা যুকত করার জনে

function editproductinsert(Request $request){

	if($request->hasFile('Product_image')){
		if(productModel::find($request->product_id)->Product_image == 'defaultproductphoto.jpg'){



    		$photo_to_upload = $request->Product_image;
    		$filename = $request->product_id.".".$photo_to_upload->getClientOriginalExtension();
    		Image::make($photo_to_upload)->resize(400,450)->save(base_path('public/uploads/product_photos/'.$filename),85);
    		productModel::find($request->product_id)->update([
    			'Product_image' => $filename
    		]);



		}
		else{

			$delete_this_file = productModel::find($request->product_id)->Product_image;
			unlink(base_path('public/uploads/product_photos/'.$delete_this_file));


			$photo_to_upload = $request->Product_image;
    		$filename = $request->product_id.".".$photo_to_upload->getClientOriginalExtension();
    		Image::make($photo_to_upload)->resize(400,450)->save(base_path('public/uploads/product_photos/'.$filename),85);
    		productModel::find($request->product_id)->update([
    			'Product_image' => $filename
    		]);



		}


	}

	productModel::find($request->product_id)->update([
		'Product_Name' => $request->Product_Name_josim,
		'Product_Description' => $request->Product_Description,
		'Product_Price' => $request->Product_Price,
		'Product_Quentity' => $request->Product_Quentity,
		'Product_Alert_Quentity' => $request->Product_Alert_Quentity,

	]);
	return back()->with('updatestatus', 'Product Update SuccessFully!');
}


function deleteproduct($product_id){
    productModel::where('id', $product_id)->delete();
    return back()->with('deletestatus', 'Product Delete SuccessFully!');
}


function restore_product($product_id){
	productModel::onlyTrashed()->find($product_id)->restore();
	return back();
}



function permantlyDeleteProduct($product_id){
	if($delete_this_file = productModel::onlyTrashed()->find($product_id)->Product_image == 'defaultproductphoto.jpg'){
		echo "default";
	}
	else{
		$delete_this_file = productModel::onlyTrashed()->find($product_id)->Product_image;
		unlink(base_path('public/uploads/product_photos/'.$delete_this_file));
	}
    
    
    
    
    productModel::onlyTrashed()->find($product_id)->forceDelete();
        return back();
    }




}
