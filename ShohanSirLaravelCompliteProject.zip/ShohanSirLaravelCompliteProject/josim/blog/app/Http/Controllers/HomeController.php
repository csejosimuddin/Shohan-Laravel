<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use PDF;
use App\order;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $all_user = User::all();
         return view('home',compact('all_user'));
    }


    function createpdf($order_id){
        $user_id = order::find($order_id)->user_id;
        $customer_name = User::find($user_id)->name;
        $pdf = PDF::loadView('frontend.pdf.invoice', compact('order_id', 'customer_name'));
        $file_name = "Invoice No - ".$order_id.".Pdf";
        return $pdf->stream($file_name);

    }



}
