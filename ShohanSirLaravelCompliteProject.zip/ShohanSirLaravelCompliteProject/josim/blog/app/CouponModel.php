<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CouponModel extends Model
{
    public $table='Coupon';
    public $primaryKey='id';
    public $incrementing=true;
    public $keyType='int';
    public  $timestamps=true;

    protected $fillable = ['coupon_name','Coupon_Percentage','Valid_Till'];
}
