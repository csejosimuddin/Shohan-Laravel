<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('create/pdf/{order_id}', 'HomeController@createpdf');

// Backend Product or CRUD Operation Route
Route::get('/Add/Product/View','ProductCongtroller@index');
Route::post('/add/product/insert','ProductCongtroller@addproductinsert');
Route::get('/edit/product/{product_id}','ProductCongtroller@editproduct');
Route::post('/edit/product/insert','ProductCongtroller@editproductinsert');
Route::get('/delete/product/{product_id}','ProductCongtroller@deleteproduct');
Route::get('/restore/product/{product_id}','ProductCongtroller@restore_product');
Route::get('/permantlyDelete/product/{product_id}','ProductCongtroller@permantlyDeleteProduct');

// Category
Route::get('/Add/Category/View','CategoryCongtroller@view');
Route::post('/add/category/insert','CategoryCongtroller@addcategoryinsert');
Route::get('category/wise/product/{category_id}','frontendController@categorywiseproduct');
Route::get('change/menu/status/{category_id}','CategoryCongtroller@changemenustatus');

// Frontend Operation
Route::get('/', 'frontendController@index');
Route::get('product/Details/{product_id}', 'frontendController@productDetails');

// Contact Page
Route::get('contact/view', 'ContactController@contactView');
Route::post('contact/insert','ContactController@contactinsert');
// Backend Contact Route View
Route::get('Message/Back/View', 'ContactController@contactbackview');
Route::get('Message/Read/status/{message_id}','ContactController@MessageReadstatus');



// ADD TO CART PAGE ROUTE
Route::get('add/to/cart/{product_id}', 'Cartcontroller@addtocart');

Route::get('CartView', 'Cartcontroller@CartView');
Route::get('CartView/{Coupon_name}', 'Cartcontroller@CartView');

Route::get('Cart/Delete/{product_id}', 'Cartcontroller@CartDelete');
Route::get('Cart/clear', 'Cartcontroller@Cartclear');
Route::post('update/cart', 'Cartcontroller@updatecart');


// Coupon Related Route
Route::get('coupon/view', 'CouponController@couponview');
Route::post('add/coupon', 'CouponController@addcoupon');


// ProcessToCheckout
Route::post('ProcessToCheckout/view', 'ProcessToCheckout@ProcessToCheckout')->name('Checkout');

// Customer/registation
Route::get('Customer/registation/view', 'CustomerRegistation@Customerregistationview')->name('Customerregistation');
Route::post('Customer/Register', 'CustomerRegistation@CustomerRegister')->name('Registation');
Route::get('customer/Dashboird', 'CustomerRegistation@customerDashboird');
Route::get('order/details/{order_id}', 'CustomerRegistation@orderdetails');
// Customer review Option Route
Route::get('submit/review/{order_history_id}', 'CustomerRegistation@submitreview');
Route::post('submit/review/insert', 'CustomerRegistation@submitreviewinsert');

// Change/SetPassword
Route::get('Change/SetPassword', 'CustomerRegistation@ChangeSetPassword');
Route::post('Change/password', 'CustomerRegistation@Changepassword');

// customer/profile
Route::get('customer/profile', 'customerprofile_controller@customerprofile');
Route::post('my/profile/insert', 'customerprofile_controller@myprofileinsert');
Route::post('my/profile/update', 'customerprofile_controller@myprofileupdate');

// ProcessTo checkout page Ajex ar link 
Route::post('/get/districts', 'ProcessToCheckout@getdistricts');

Route::post('checkout/submit', 'ProcessToCheckout@checkoutsubmit')->name('checkoutsubmit');

// Creadit card Payment Getway
Route::get('stripe', 'StripePaymentController@stripe');
Route::post('stripe', 'StripePaymentController@stripePost')->name('stripe.post');

