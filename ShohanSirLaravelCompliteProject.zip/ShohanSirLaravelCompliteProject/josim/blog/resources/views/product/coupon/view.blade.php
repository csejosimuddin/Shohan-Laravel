@extends('layouts.app')
@section('content')

<div class="container">
    <div class="row">
        <div class="col-lg-4">
            <div class="card px-3 py-3">

            @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif


                <form action="{{ url('/add/coupon') }}" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <label>Coupon Name</label>
                        <input type="text" class="form-control" name="coupon_name" placeholder="Enter coupon_name"
                            value="{{ old('coupon_name') }}">
                    </div>
                    <div class="form-group">
                        <label>Coupon Percentage</label>
                        <input type="text" class="form-control" name="Coupon_Percentage"
                            placeholder="Enter Coupon_Percentage" value="{{ old('Coupon_Percentage') }}">
                    </div>
                    <div class="form-group">
                        <label>Valid_Till</label>
                        <input type="date" class="form-control" name="Valid_Till" value="{{ old('Valid_Till') }}">
                    </div>

                    <button type="submit" class="btn btn-info">Submit</button>
                </form>



            </div>
        </div>


        <div class="col-lg-8">
            <!-- এর মাধমে success alert টা পাবো -->
            @if(session('deletestatus'))
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-danger">
                {{ session('deletestatus') }}
            </div>
            @endif
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>SL.NO</th>
                        <th>Coupon Name</th>
                        <th>Coupon Percentage</th>
                        <th>Valid_Till</th>
                        <th>created_at</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse($coupon_Show as $coupon)
                    <tr>

                    <td>{{ $loop->index+1 }}</td>
                        <td>{{$coupon->coupon_name}}</td>
                        <td>{{$coupon->coupon_percentage}}</td>
                        <td>{{$coupon->valid_till}}</td>
                        <td>{{ $coupon->created_at }}</td>
                    </tr>
                    @empty
                        <tr>
                        <td>Coupon Not Avabialle!</td>
                        </tr>
                    @endforelse

                </tbody>
            </table>







        </div>



    </div>
</div>


    @endsection