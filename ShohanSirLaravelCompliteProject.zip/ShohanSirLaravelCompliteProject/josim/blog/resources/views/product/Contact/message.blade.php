@extends('layouts.app')
@section('content')

<div class="col-lg-8 offset-2">
<h2>Contact Message view</h2>
<table class="table table-bordered mt-5">
            <thead>
               <tr>
                  <th>First Name</th>
                  <th>subject</th>
                  <th>Message</th>
                  <th>Action</th>
               </tr>
            </thead>
            <tbody>

            @foreach($ContactMessage as $Contact)
               <tr class={{ ($Contact->read_status==1)? "bg-info":"" }}>
                  <td>{{ $Contact->first_name }}</td>
                  <td>{{ $Contact->subject }}</td>
                  <td>{{ $Contact->	message }}</td>
                  <td>
                            <a href="{{ url('Message/Read/status') }}/{{ $Contact->id }}"
                                class="btn btn-sm btn-info">Read</a>
                        </td>
               </tr>

               @endforeach
             
            </tbody>
         </table>
         {{ $ContactMessage->links() }}
</div>


@endsection