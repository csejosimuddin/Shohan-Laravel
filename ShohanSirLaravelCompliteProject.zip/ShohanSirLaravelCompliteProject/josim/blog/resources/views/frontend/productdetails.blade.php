
@extends('layouts.frontendapp')
@section('title','HomePAge')
@section('content')



<section id="section-padding">
<div class="container">
	<div class="row">
		<div class="col-lg-6">
			<img src="{{ asset('uploads/product_photos') }}/{{ $single_product_info->Product_image }}" width="100%" height="auto">
			
		</div>

		<div class="col-lg-6">
			<h2>{{$single_product_info->Product_Name}}</h2>
			<td>Categori Name:{{ $single_product_info->relationtocategory->category_id }}</td>
			<p>{{$single_product_info->Product_Description}}</p>
			
			@if($single_product_info->Product_Quentity >0)
			<a href="{{ url('add/to/cart') }}/{{ $single_product_info->id }}" class="site-btn btn-line">Add To Cart</a>
			@else
			<div class="alert alert-danger">
			This Product is Not Avaiable!
			</div>
			@endif
			
			<div class="review">
			@php
			if(App\review::where('product_id', $single_product_info->id)->exists()){
			$sum = App\review::where('product_id', $single_product_info->id)->sum('points');
			$count = App\review::where('product_id', $single_product_info->id)->count();
			$review_points = $sum/$count;
			$review_points;
			}
			else{
				$sum = 0;
				$count = 0;
				$review_points = 0;

			}
			@endphp
			<div class="rating">
			@if($review_points == 0) 
			Review Not Yet
			@elseif(1 <= $review_points && $review_points <=1.9) 
			<i class="fa fa-star" aria-hidden="true"><
			@elseif(2 <= $review_points && $review_points <=2.9)
			<i class="fa fa-star" aria-hidden="true"></i>
			<i class="fa fa-star" aria-hidden="true"></i>
			@elseif(3 <= $review_points && $review_points <=3.9)
			<i class="fa fa-star" aria-hidden="true"></i>
			<i class="fa fa-star" aria-hidden="true"></i>
			<i class="fa fa-star" aria-hidden="true"></i>
			@elseif(4 <= $review_points && $review_points <=4.9)
			<i class="fa fa-star" aria-hidden="true"></i>
			<i class="fa fa-star" aria-hidden="true"></i>
			<i class="fa fa-star" aria-hidden="true"></i>
			<i class="fa fa-star" aria-hidden="true"></i>
			@else
			<i class="fa fa-star" aria-hidden="true"></i>
			<i class="fa fa-star" aria-hidden="true"></i>
			<i class="fa fa-star" aria-hidden="true"></i>
			<i class="fa fa-star" aria-hidden="true"></i>
			<i class="fa fa-star" aria-hidden="true"></i>
			@endif

			</div>
			</div>
		</div>
		
	</div>
	
</div>

</section>



<style type="text/css">
	#section-padding{
		padding: 80px 0px;
	}
</style>

<section id="section-padding">
	<div class="related text-center">	<h1>Related Product</h1></div>
	<div class="container">
		<div class="row">

        @foreach($related_product as $related_product)
			<div class="col-lg-4">
            <a href="{{ url('product/Details') }}/{{ $related_product->id }}" class="site-btn btn-line">
				<img src="{{ asset('uploads/product_photos') }}/{{ $related_product->Product_image }}" width="100%" height="auto">
                </a>
				<h5>{{ $related_product->Product_Name }}</h5>
                <span>{{ $related_product->Product_Price }}</span>
				
				<a href="#">Add To Cart</a>
			</div>
@endforeach

		 </div>
		
	</div>
</section>
@endsection