@extends('layouts.app')
@section('content')


<div class="container">
	<div class="row">
		<div class="col-6 offset-3">
			<div class="card mb-3">
				<div class="card-header">
					set/Change Password
					
				</div>
				<div class="card-body">
					@if($errors->all())
					<div class="alert alert-danger" role="alert">
						
				
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
						</div>
						@endif

					<!-- password Change করার জনে -->
			 <form action="{{ url('Change/password') }}" method="post">
               @csrf

               <div class="form-group">

               	                  <label>Old Password</label>
                  <input type="password" class="form-control" name="oldpassword" placeholder="Enter Your Password" value="{{ old('newpassword') }}">
                  <label>New Password</label>
                  <input type="password" class="form-control" name="newpassword" placeholder="Enter Your Password" value="{{ old('newpassword') }}">

                  <label>Confirm Password</label>
                  <input type="password" class="form-control" name="confirmpassword" placeholder="Enter Your Confirm Password" value="{{ old('confirmpassword') }}">

               </div>
               
              
          <button type="submit" class="btn btn-info">Change Password</button>
            </form>	
					
				</div>
				
			</div>
			
		</div>
		
	</div>
	
</div>


@endsection