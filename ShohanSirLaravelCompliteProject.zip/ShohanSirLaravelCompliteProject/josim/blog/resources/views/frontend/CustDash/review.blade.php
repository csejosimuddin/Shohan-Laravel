@extends('layouts.app')
@section('content')


<div class="container">
    <div class="row">
        <div class="col-lg-8 offset-2">

            <div class="card-body">

            @if(App\review::where('product_id', $product_id)->exists())

        echo "আপনি একবার রিভিউ দিয়েছেন আর না বস";
            @else
                <form method="post" action="{{ url('submit/review/insert') }}">
                    @csrf
                    <div class="form-group">
                        <input type="hidden" name="order_history_id" value="{{ $order_history_id }}">
                        <input type="hidden" name="product_id" value="{{ $product_id }}">
                        <label for="one">Your Comment</label>
                        <textarea class="form-control" name="Comment" rows="5"></textarea>

                    </div>

                    <div class="form-group">
                        <label for="one2">Your Comment</label>
                        <input class="form-control" type="range" name="points" min="1" max="5" step="1"
                            value="1"></input>

                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>

                </form>

                @endif
            </div>

        </div>
    </div>
</div>

@endsection