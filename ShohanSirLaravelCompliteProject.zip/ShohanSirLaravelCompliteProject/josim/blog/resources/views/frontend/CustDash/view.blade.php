@extends('layouts.app')
@section('content')


<div class="container">
<div class="row">
<div class="col-lg-12 p-0">
<h2 class="bg-primary text-center" style="color: #fff;" >Customir Product Parches List</h2>
</div>

<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Total Amount</th>
      <th scope="col">payment Type</th>
      <th scope="col">Payment Status</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  @foreach($order as $order)
    <tr>
      <td>{{$order->total_amount_show}}</td>
      <td>{{($order->payment_type == 1) ? "Cash On Delivery":"Card Payment"}}</td>
      <td>{{($order->payment_status == 1) ? "Pending":"success"}}</td>
      <td>
      <a href="{{ url('order/details') }}/{{ $order->id }}">View</a>
      </td>
    </tr>
    @endforeach
  </tbody>
</table>



</div>
</div>

@endsection