<h2>This is Customer Invoice</h2>
<h1>Customer Order ID: {{ $order_id }}</h1>
<h1>Customer Name: {{ $customer_name }}</h1>