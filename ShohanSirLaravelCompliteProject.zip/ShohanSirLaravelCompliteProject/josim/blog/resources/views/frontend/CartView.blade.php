@extends('layouts.frontendapp')
@section('title','CartView')
@section('content')



<div class="page-area cart-page spad">
    <div class="container">
        <div class="cart-table">
            <form action="{{ url('update/cart') }}" method="post">
                @csrf

                <table>
                    <thead>
                        <tr>
                            <th class="product-th">Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th class="total-th">Total</th>
                        </tr>
                    </thead>
                    <tbody>

                        @php
                        $Subtotal = 0;
                        @endphp

                        @forelse($CartallProduct as $CartallProduct)
                        <tr>
                            <td class="product-col">
                                <img src="{{ asset('uploads/product_photos') }}/{{ App\productModel::find($CartallProduct->product_id)-> Product_image }}"
                                    alt="kkk" width="80">
                                <div class="pc-title">
                                    <h4>{{ App\productModel::find($CartallProduct->product_id)-> Product_Name}}</h4>
                                    <a href="{{ url('Cart/Delete') }}/{{ $CartallProduct->id }}">Delete Product</a>

                                    @if(App\productModel::find($CartallProduct->product_id)-> Product_Quentity == 0)
                                    <div class="alert alert-danger">
                                        <h4>this product stock out please delete this</h4>

                                    </div>
                                    @endif

                                </div>
                            </td>
                            <td class="price-col">
                                ${{ App\productModel::find($CartallProduct->product_id)-> Product_Price}}</td>
                            <td class="quy-col">
                                <div class="quy-input">
                                    <span>Qty</span>
                                    <input type="hidden" value="{{ $CartallProduct->product_id }}" name="product_id[]">
                                    <input type="number" value="{{ $CartallProduct->product_quantity }}"
                                        name="product_quantity[]">
                                </div>
                            </td>
                            <td class="total-col">
                                ${{ (App\productModel::find($CartallProduct->product_id)-> Product_Price)*($CartallProduct->product_quantity) }}
                            </td>
                            @php
                            $Subtotal = $Subtotal+((App\productModel::find($CartallProduct->product_id)->
                            Product_Price)*($CartallProduct->product_quantity));
                            @endphp
                        </tr>
                        @empty
                        @endforelse

                    </tbody>
                </table>



        </div>
        <div class="row cart-buttons">
            <div class="col-lg-5 col-md-5">
                <a href="{{ url('/') }}">
                    <div class="site-btn btn-continue">Continue shooping</div>
                </a>
            </div>
            <div class="col-lg-7 col-md-7 text-lg-right text-left">
                <a href="{{ url('Cart/clear') }}">
                    <div class="site-btn btn-clear">Clear cart</div>
                </a>
                <button type="submit" class="site-btn btn-line btn-update">Update Cart</button>
            </div>
        </div>
        </form>
    </div>
    <div class="card-warp">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="shipping-info">
                        <h4>Shipping method</h4>
                        <p>Select the one you want</p>
                        <div class="shipping-chooes">
                            <div class="sc-item">
                                <input type="radio" name="sc" id="one">
                                <label for="one" id="sm_one">Next day delivery<span>$4.99</span></label>
                            </div>
                            <div class="sc-item">
                                <input type="radio" name="sc" id="two">
                                <label for="two" id="sm_two">Standard delivery<span>$1.99</span></label>
                            </div>
                            <div class="sc-item">
                                <input type="radio" name="sc" id="three">
                                <label for="three" id="sm_three">Personal Pickup<span>Free</span></label>
                            </div>
                        </div>
                        <h4>Cupon code</h4>
                        <p>Enter your cupone code</p>
                        <div class="cupon-input">
                            <input type="text" id="coupon_code_input_field" value="{{ $Coupon_name }}">
                            <button class="site-btn" id="coupon_name">Apply</button>
                        </div>
                    </div>
                </div>
                <div class="offset-lg-2 col-lg-6">
                    <div class="cart-total-details">
                        <h4>Cart total</h4>
                        <p>Final Info</p>
                        <ul class="cart-total-card">
                            <li>Subtotal<span>${{ $Subtotal }}</span></li>
                            <li>Shipping<span id="shipping_amount">0</span><span>$</span></li>
                            <li>Coupon Discuont <b>({{ $copuen_percentage }}%)</b>
                                <span>{{ $Subtotal*($copuen_percentage/100) }} </span></li>
                            <li class="total">Total<span  id="total_amount_show">{{$Subtotal-($Subtotal)*($copuen_percentage/100)}}</span><span>$</span></li>
                            <li class="total" style="display: none">Total<span  id="total_amount">{{$Subtotal-($Subtotal)*($copuen_percentage/100)}}</span></li>
                        </ul>



                        <form action="{{ route('Checkout') }}" method="POST">
                        @csrf
                        <input type="hidden" name="Subtotal"  value="{{ $Subtotal }}">
                        <input type="hidden" name="Shipping"  value="0" id="shipping_amount1">
                        <input type="hidden" name="cupon_discount"  value="{{ $Subtotal*($copuen_percentage/100) }}">
                        <input type="hidden" name="total_amount_show" id="final_total_amount" value="{{$Subtotal-($Subtotal)*($copuen_percentage/100)}}">
                        <button type="submit" class="site-btn btn-full">Proceed to checkout</button>                 
                        </form>


                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection


@section('footer_script')

<script type="text/javascript">
$(document).ready(function() {
    // Coupon Add JQuery

    $("#coupon_name").click(function() {
        var Coupon_Code = $("#coupon_code_input_field").val();
        var link_to_go = "{{ url('/CartView') }}/"+Coupon_Code;
        window.location.href = link_to_go;
        // var link_to_go = "{{ url('/CartView') }}/" + Coupon_Code;
        // window.location.href = link_to_go;

    });



    // Shipping Add JQuery
    $("#sm_one").click(function(){
        $("#shipping_amount").html(4.99);
        $("#shipping_amount1").val(4.99);
        var total_amount = parseFloat($('#total_amount').html()) + parseFloat(4.99);
        $("#total_amount_show").html(total_amount);
        $("#final_total_amount").val(total_amount);
    })
    
    $("#sm_two").click(function(){
        $("#shipping_amount").html(1.99);
        $("#shipping_amount1").val(1.99);
        var total_amount_two = parseFloat($('#total_amount').html()) + parseFloat(1.99);
        $("#total_amount_show").html(total_amount_two);
        $("#final_total_amount").val(total_amount_two);
    })
    
    $("#sm_three").click(function(){
        $("#shipping_amount").html(0);
        $("#shipping_amount1").val(0);
        var total_amount_three = parseFloat($('#total_amount').html()) + parseFloat(0);
       $("#total_amount_show").html(total_amount_three);
       $("#final_total_amount").val(total_amount_three);
    })


});
</script>

@endsection