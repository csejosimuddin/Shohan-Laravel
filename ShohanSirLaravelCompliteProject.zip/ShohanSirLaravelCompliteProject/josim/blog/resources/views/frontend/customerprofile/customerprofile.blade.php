
@extends('layouts.app')
@section('content')


<div class="container">
<div class="row">
<div class="col-lg-8 offset-2">

@if(App\customerprofile::where('user_id', Auth::id())->exists())


<form method="POST" action="{{ url('my/profile/update') }}">
	 @csrf
 <div class="form-group">
 	<label>Company</label>
 	<input type="text" class="form-control" name="Company" value="{{ old('Company') }}">
</div>

 <div class="form-group">
 	<label>Address</label>
 	<textarea name="address" rows="5" class="form-control" value="{{ old('address') }}"></textarea>
</div>

<div class="form-group">
 	<label>Zip Code</label>
 	<input type="text" class="form-control" name="ZipCode" value="{{ old('ZipCode') }}" placeholder="Enter Your ZipCode ">
</div>


<div class="form-group">
 	<label>Phone Number</label>
 	<input type="text" class="form-control" name="PhoneNumber" value="{{ old('PhoneNumber') }}" placeholder="Enter Your ZipCode ">
</div>
<button type="submit" class="btn btn-success">Update Your Profile</butto>
</form>


@else



<form method="POST" action="{{ url('my/profile/insert') }}">
 	@csrf
 <div class="form-group">
 	<label>Company</label>
 	<input type="text" class="form-control" name="Company" value="{{ old('email') }}" placeholder="Enter Your Company Name">
</div>

 <div class="form-group">
 	<label>Address</label>
 	<textarea name="address" rows="5" class="form-control"></textarea>
</div>

<div class="form-group">
 	<label>Zip Code</label>
 	<input type="text" class="form-control" name="ZipCode" value="{{ old('ZipCode') }}" placeholder="Enter Your ZipCode ">
</div>


<div class="form-group">
 	<label>Phone Number</label>
 	<input type="text" class="form-control" name="PhoneNumber" value="{{ old('PhoneNumber') }}" placeholder="Enter Your ZipCode ">
</div>
<button type="submit" class="btn btn-success">Submit</button>

 </form>



@endif


</div>
</div>
</div>



 @endsection