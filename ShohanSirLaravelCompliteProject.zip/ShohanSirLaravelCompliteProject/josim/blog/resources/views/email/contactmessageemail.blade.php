<h1>Hello, I am, {{ $first_name_to_send }}</h1>
<p>{{ $message_to_send }}</p>