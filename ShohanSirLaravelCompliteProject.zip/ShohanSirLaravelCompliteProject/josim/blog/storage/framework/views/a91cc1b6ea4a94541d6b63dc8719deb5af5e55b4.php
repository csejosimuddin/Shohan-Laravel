<h2>This is Customer Invoice</h2>
<h1>Customer Order ID: <?php echo e($order_id); ?></h1>
<h1>Customer Name: <?php echo e($customer_name); ?></h1><?php /**PATH C:\Users\Josim\Desktop\Desktop\josim\blog\resources\views/frontend/pdf/invoice.blade.php ENDPATH**/ ?>