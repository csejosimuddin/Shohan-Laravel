<?php $__env->startSection('content'); ?>


<div class="container">
<div class="row">
<div class="col-lg-8 offset-2">

<?php if(App\customerprofile::where('user_id', Auth::id())->exists()): ?>


<form method="POST" action="<?php echo e(url('my/profile/update')); ?>">
	 <?php echo csrf_field(); ?>
 <div class="form-group">
 	<label>Company</label>
 	<input type="text" class="form-control" name="Company" value="<?php echo e(old('Company')); ?>">
</div>

 <div class="form-group">
 	<label>Address</label>
 	<textarea name="address" rows="5" class="form-control" value="<?php echo e(old('address')); ?>"></textarea>
</div>

<div class="form-group">
 	<label>Zip Code</label>
 	<input type="text" class="form-control" name="ZipCode" value="<?php echo e(old('ZipCode')); ?>" placeholder="Enter Your ZipCode ">
</div>


<div class="form-group">
 	<label>Phone Number</label>
 	<input type="text" class="form-control" name="PhoneNumber" value="<?php echo e(old('PhoneNumber')); ?>" placeholder="Enter Your ZipCode ">
</div>
<button type="submit" class="btn btn-success">Update Your Profile</butto>
</form>


<?php else: ?>



<form method="POST" action="<?php echo e(url('my/profile/insert')); ?>">
 	<?php echo csrf_field(); ?>
 <div class="form-group">
 	<label>Company</label>
 	<input type="text" class="form-control" name="Company" value="<?php echo e(old('email')); ?>" placeholder="Enter Your Company Name">
</div>

 <div class="form-group">
 	<label>Address</label>
 	<textarea name="address" rows="5" class="form-control"></textarea>
</div>

<div class="form-group">
 	<label>Zip Code</label>
 	<input type="text" class="form-control" name="ZipCode" value="<?php echo e(old('ZipCode')); ?>" placeholder="Enter Your ZipCode ">
</div>


<div class="form-group">
 	<label>Phone Number</label>
 	<input type="text" class="form-control" name="PhoneNumber" value="<?php echo e(old('PhoneNumber')); ?>" placeholder="Enter Your ZipCode ">
</div>
<button type="submit" class="btn btn-success">Submit</button>

 </form>



<?php endif; ?>


</div>
</div>
</div>



 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim\Desktop\Desktop\josim\blog\resources\views/frontend/customerprofile/customerprofile.blade.php ENDPATH**/ ?>