<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-lg-4">
            <div class="card px-3 py-3">

            <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


                <form action="<?php echo e(url('/add/coupon')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>



                    <div class="form-group">
                        <label>Coupon Name</label>
                        <input type="text" class="form-control" name="coupon_name" placeholder="Enter coupon_name"
                            value="<?php echo e(old('coupon_name')); ?>">
                    </div>
                    <div class="form-group">
                        <label>Coupon Percentage</label>
                        <input type="text" class="form-control" name="Coupon_Percentage"
                            placeholder="Enter Coupon_Percentage" value="<?php echo e(old('Coupon_Percentage')); ?>">
                    </div>
                    <div class="form-group">
                        <label>Valid_Till</label>
                        <input type="date" class="form-control" name="Valid_Till" value="<?php echo e(old('Valid_Till')); ?>">
                    </div>

                    <button type="submit" class="btn btn-info">Submit</button>
                </form>



            </div>
        </div>


        <div class="col-lg-8">
            <!-- এর মাধমে success alert টা পাবো -->
            <?php if(session('deletestatus')): ?>
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-danger">
                <?php echo e(session('deletestatus')); ?>

            </div>
            <?php endif; ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>SL.NO</th>
                        <th>Coupon Name</th>
                        <th>Coupon Percentage</th>
                        <th>Valid_Till</th>
                        <th>created_at</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $coupon_Show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>

                    <td><?php echo e($loop->index+1); ?></td>
                        <td><?php echo e($coupon->coupon_name); ?></td>
                        <td><?php echo e($coupon->coupon_percentage); ?></td>
                        <td><?php echo e($coupon->valid_till); ?></td>
                        <td><?php echo e($coupon->created_at); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                        <td>Coupon Not Avabialle!</td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>







        </div>



    </div>
</div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim\Desktop\Desktop\josim\blog\resources\views/product/coupon/view.blade.php ENDPATH**/ ?>