<?php $__env->startSection('title','HomePAge'); ?>
<?php $__env->startSection('content'); ?>



<section id="section-padding">
<div class="container">
	<div class="row">
		<div class="col-lg-6">
			<img src="<?php echo e(asset('uploads/product_photos')); ?>/<?php echo e($single_product_info->Product_image); ?>" width="100%" height="auto">
			
		</div>

		<div class="col-lg-6">
			<h2><?php echo e($single_product_info->Product_Name); ?></h2>
			<td>Categori Name:<?php echo e($single_product_info->relationtocategory->category_id); ?></td>
			<p><?php echo e($single_product_info->Product_Description); ?></p>
			
			<?php if($single_product_info->Product_Quentity >0): ?>
			<a href="<?php echo e(url('add/to/cart')); ?>/<?php echo e($single_product_info->id); ?>" class="site-btn btn-line">Add To Cart</a>
			<?php else: ?>
			<div class="alert alert-danger">
			This Product is Not Avaiable!
			</div>
			<?php endif; ?>
			
		</div>
		
	</div>
	
</div>

</section>



<style type="text/css">
	#section-padding{
		padding: 80px 0px;
	}
</style>

<section id="section-padding">
	<div class="related text-center">	<h1>Related Product</h1></div>
	<div class="container">
		<div class="row">

        <?php $__currentLoopData = $related_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-4">
            <a href="<?php echo e(url('product/Details')); ?>/<?php echo e($related_product->id); ?>" class="site-btn btn-line">
				<img src="<?php echo e(asset('uploads/product_photos')); ?>/<?php echo e($related_product->Product_image); ?>" width="100%" height="auto">
                </a>
				<h5><?php echo e($related_product->Product_Name); ?></h5>
                <span><?php echo e($related_product->Product_Price); ?></span>
				
				<a href="#">Add To Cart</a>
			</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		 </div>
		
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim\Desktop\josim\blog\resources\views/frontend/productdetails.blade.php ENDPATH**/ ?>