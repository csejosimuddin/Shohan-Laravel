<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-lg-6 offset-3">

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Dashbord</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/Add/Product/View')); ?>">Product List</a></li>
                    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($single_product_info-> Product_Name); ?>

                    </li>
                </ol>
            </nav>





            <div class="card px-3 py-3">
                <div class="card-header bg-success">
                    Edit Product Form
                </div>
                <?php if(session('updatestatus')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('updatestatus')); ?>

                </div>
                <?php endif; ?>

                <form action="<?php echo e(url('/edit/product/insert')); ?>" method="post" enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Product Name</label>


                        <input type="hidden" class="form-control" name="product_id" placeholder="Enter Product Name"
                            value="<?php echo e($single_product_info-> id); ?>">
                        <input type="text" class="form-control" name="Product_Name_josim"
                            placeholder="Enter Product Name" value="<?php echo e($single_product_info-> Product_Name); ?>">
                    </div>
                    <div class="form-group">
                        <label>Product Description</label>
                        <textarea class="form-control" name="Product_Description" rows="3"
                            placeholder="Enter Product Description"><?php echo e($single_product_info-> Product_Description); ?></textarea>


                    </div>
                    <div class="form-group">
                        <label>Product Price</label>
                        <input type="text" class="form-control" name="Product_Price" placeholder="Enter Product Price"
                            value="<?php echo e($single_product_info-> Product_Price); ?>">
                    </div>
                    <div class="form-group">
                        <label>Product Quentity</label>
                        <input type="text" class="form-control" name="Product_Quentity"
                            placeholder="Enter Product Quentity" value="<?php echo e($single_product_info-> Product_Quentity); ?>">
                    </div>
                    <div class="form-group">
                        <label>Product Alert Quentity</label>
                        <input type="text" class="form-control" name="Product_Alert_Quentity"
                            placeholder="Enter Product Alert Quentity"
                            value="<?php echo e($single_product_info->	Product_Alert_Quentity); ?>">
                    </div>

                    <div class="form-group">
                        <label>Product image</label>
                        <input type="file" class="form-control" name="Product_image">
                    </div>


                    <img src="<?php echo e(asset('uploads/product_photos')); ?>/<?php echo e($single_product_info->Product_image); ?>"
                        alt="No Images Found" width="100">


                    <button type="submit" class="btn btn-success">Update</button>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim\Desktop\Desktop\josim\blog\resources\views/Product/productedite.blade.php ENDPATH**/ ?>