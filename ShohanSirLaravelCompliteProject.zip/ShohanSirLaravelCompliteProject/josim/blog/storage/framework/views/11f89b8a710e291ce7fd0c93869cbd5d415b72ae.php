<?php $__env->startSection('title','CartView'); ?>
<?php $__env->startSection('content'); ?>



<div class="page-area cart-page spad">
    <div class="container">
        <div class="cart-table">
            <form action="<?php echo e(url('update/cart')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <table>
                    <thead>
                        <tr>
                            <th class="product-th">Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th class="total-th">Total</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
                        $Subtotal = 0;
                        ?>

                        <?php $__empty_1 = true; $__currentLoopData = $CartallProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CartallProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="product-col">
                                <img src="<?php echo e(asset('uploads/product_photos')); ?>/<?php echo e(App\productModel::find($CartallProduct->product_id)-> Product_image); ?>"
                                    alt="kkk" width="80">
                                <div class="pc-title">
                                    <h4><?php echo e(App\productModel::find($CartallProduct->product_id)-> Product_Name); ?></h4>
                                    <a href="<?php echo e(url('Cart/Delete')); ?>/<?php echo e($CartallProduct->id); ?>">Delete Product</a>

                                    <?php if(App\productModel::find($CartallProduct->product_id)-> Product_Quentity == 0): ?>
                                    <div class="alert alert-danger">
                                        <h4>this product stock out please delete this</h4>

                                    </div>
                                    <?php endif; ?>

                                </div>
                            </td>
                            <td class="price-col">
                                $<?php echo e(App\productModel::find($CartallProduct->product_id)-> Product_Price); ?></td>
                            <td class="quy-col">
                                <div class="quy-input">
                                    <span>Qty</span>
                                    <input type="hidden" value="<?php echo e($CartallProduct->product_id); ?>" name="product_id[]">
                                    <input type="number" value="<?php echo e($CartallProduct->product_quantity); ?>"
                                        name="product_quantity[]">
                                </div>
                            </td>
                            <td class="total-col">
                                $<?php echo e((App\productModel::find($CartallProduct->product_id)-> Product_Price)*($CartallProduct->product_quantity)); ?>

                            </td>
                            <?php
                            $Subtotal = $Subtotal+((App\productModel::find($CartallProduct->product_id)->
                            Product_Price)*($CartallProduct->product_quantity));
                            ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>

                    </tbody>
                </table>



        </div>
        <div class="row cart-buttons">
            <div class="col-lg-5 col-md-5">
                <a href="<?php echo e(url('/')); ?>">
                    <div class="site-btn btn-continue">Continue shooping</div>
                </a>
            </div>
            <div class="col-lg-7 col-md-7 text-lg-right text-left">
                <a href="<?php echo e(url('Cart/clear')); ?>">
                    <div class="site-btn btn-clear">Clear cart</div>
                </a>
                <button type="submit" class="site-btn btn-line btn-update">Update Cart</button>
            </div>
        </div>
        </form>
    </div>
    <div class="card-warp">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="shipping-info">
                        <h4>Shipping method</h4>
                        <p>Select the one you want</p>
                        <div class="shipping-chooes">
                            <div class="sc-item">
                                <input type="radio" name="sc" id="one">
                                <label for="one" id="sm_one">Next day delivery<span>$4.99</span></label>
                            </div>
                            <div class="sc-item">
                                <input type="radio" name="sc" id="two">
                                <label for="two" id="sm_two">Standard delivery<span>$1.99</span></label>
                            </div>
                            <div class="sc-item">
                                <input type="radio" name="sc" id="three">
                                <label for="three" id="sm_three">Personal Pickup<span>Free</span></label>
                            </div>
                        </div>
                        <h4>Cupon code</h4>
                        <p>Enter your cupone code</p>
                        <div class="cupon-input">
                            <input type="text" id="coupon_code_input_field" value="<?php echo e($Coupon_name); ?>">
                            <button class="site-btn" id="coupon_name">Apply</button>
                        </div>
                    </div>
                </div>
                <div class="offset-lg-2 col-lg-6">
                    <div class="cart-total-details">
                        <h4>Cart total</h4>
                        <p>Final Info</p>
                        <ul class="cart-total-card">
                            <li>Subtotal<span>$<?php echo e($Subtotal); ?></span></li>
                            <li>Shipping<span id="shipping_amount">0</span></li>
                            <li>Coupon Discuont <b>(<?php echo e($copuen_percentage); ?>%)</b>
                                <span><?php echo e($Subtotal*($copuen_percentage/100)); ?> </span></li>
                            <li class="total">Total<span  id="total_amount_show"><?php echo e($Subtotal-($Subtotal)*($copuen_percentage/100)); ?></span></li>
                            <li class="total" style="display: none">Total<span  id="total_amount"><?php echo e($Subtotal-($Subtotal)*($copuen_percentage/100)); ?></span></li>
                        </ul>
                        <a class="site-btn btn-full" href="<?php echo e(route('Checkout')); ?>">Proceed to checkout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer_script'); ?>

<script type="text/javascript">
$(document).ready(function() {
    // Coupon Add JQuery

    $("#coupon_name").click(function() {
        var Coupon_Code = $("#coupon_code_input_field").val();
        var link_to_go = "<?php echo e(url('/CartView')); ?>/" + Coupon_Code;
        window.location.href = link_to_go;

    });



    // Shipping Add JQuery
    $("#sm_one").click(function(){
        $("#shipping_amount").html(4.99);
        var total_amount = parseFloat($('#total_amount').html()) + parseFloat(4.99);
        $("#total_amount_show").html(total_amount);
    })
    
    $("#sm_two").click(function(){
        $("#shipping_amount").html(1.99);
        var total_amount_two = parseFloat($('#total_amount').html()) + parseFloat(1.99);
        $("#total_amount_show").html(total_amount_two);
    })
    
    $("#sm_three").click(function(){
        $("#shipping_amount").html(0);
        var total_amount_three = parseFloat($('#total_amount').html()) + parseFloat(0);
       $("#total_amount_show").html(total_amount_three);
    })


});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim\Desktop\josim\blog\resources\views/frontend/CartView.blade.php ENDPATH**/ ?>