<?php $__env->startSection('content'); ?>


<div class="container">
<div class="row">
<div class="col-lg-12 p-0">
<h2 class="bg-primary text-center" style="color: #fff;" >Customir Product Details</h2>
</div>

<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">order_id</th>
      <th scope="col">product_id</th>
      <th scope="col">Product_Name</th>
      <th scope="col">Product_Price</th>
      <th scope="col">Product_Quentity</th>
      <th scope="col">total_price</th>
      <th scope="col">Review</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $order_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($order_history->order_id); ?></td>
      <td><?php echo e($order_history->product_id); ?></td>
      <td><?php echo e(($order_history->Product_Name)); ?></td>
      <td><?php echo e($order_history->Product_Price); ?></td>
      <td><?php echo e($order_history->Product_Quentity); ?></td>
      <td><?php echo e($order_history->total_price); ?></td>
      <td>
      <a href="<?php echo e(url('submit/review')); ?>/<?php echo e($order_history->id); ?>"> Submit Your Review</a>
      
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>



</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim\Desktop\Desktop\josim\blog\resources\views/frontend/CustDash/orderdetails.blade.php ENDPATH**/ ?>