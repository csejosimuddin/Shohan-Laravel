<?php $__env->startSection('title','ProcesToCheckOut'); ?>
<?php $__env->startSection('content'); ?>



<div class="page-info-section page-info">
    <div class="container">
        <div class="site-breadcrumb">
            <a href="#">Home</a> /
            <a href="#">Sales</a> /
            <a href="#">Bags</a> /
            <a href="#">Cart</a> /
            <span>Checkout</span>
        </div>
        <img src="img/xpage-info-art.png.pagespeed.ic.M_7lJYd_wX.png" alt="" class="page-info-art">
    </div>
</div>


<div class="page-area cart-page spad">
    <div class="container">
        <form class="checkout-form" method="post" action="<?php echo e(route('checkoutsubmit')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-6">
                    <?php if(auth()->guard()->check()): ?>

                    <h4 class="checkout-title">Billing Address</h4>
                    <div class="row">
                        <div class="col-md-12">
                            <input type="text" placeholder="Full Name *"
                                value="<?php echo e(Auth::user()->name); ?>" name="full_name">
                        </div>
                        <div class="col-md-12">
                            <input type="text" placeholder="Company"
                                value="<?php echo e($customer_profile->Company); ?>" name="company">
                            <input type="text" placeholder="Address *"
                                value="<?php echo e($customer_profile->address); ?>" name="address">
                            <input type="text" name="zip_code" placeholder="Zipcode *"
                                value="<?php echo e($customer_profile->ZipCode); ?>">
                            <input type="text" placeholder="Phone no *"
                                value="<?php echo e($customer_profile->PhoneNumber); ?>" name="phone_number">
                            <input type="email" placeholder="Email Address *"
                                value="<?php echo e(Auth::user()->email); ?>" name="email_address">
                            <select id="country" name="country_id">
                                <option value="">Country *</option>
                                <?php $__currentLoopData = $divisionsmodel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divisionsmodel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($divisionsmodel->id); ?>"><?php echo e($divisionsmodel->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <select id="district" name="city_id">
                                <option>City/Town *</option>
                            </select>
                            <div class="checkbox-items">
                                <div class="ci-item">
                                    <input type="checkbox" name="a" id="tandc">
                                    <label for="tandc">Terms and conditions</label>
                                </div>
                                <div class="ci-item">
                                    <input type="checkbox" name="b" id="newaccount">
                                    <label for="newaccount">Create an account</label>
                                    <input type="password" placeholder="password">
                                </div>
                                <div class="ci-item">
                                    <input type="checkbox" name="c" id="newsletter">
                                    <label for="newsletter">Subscribe to our newsletter</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <h4 class="checkout-title">Please Login Your Account</h4>
                    <a href="<?php echo e(url('login')); ?>">Login Here</a>
                    <?php endif; ?>
                </div>
                <div class="col-lg-6">
                    <div class="order-card">
                        <div class="order-details">
                            <div class="od-warp">
                                <h4 class="checkout-title">Your order</h4>
                                <table class="order-table">

                                    <tfoot>
                                        <tr class="order-total">
                                            <th>Subtotal</th>
                                            <th>$<?php echo e($Subtotal); ?>

                                                <input type="hidden" name="Subtotal" value="<?php echo e($Subtotal); ?>">
                                            </th>
                                        </tr>

                                        <tr class="order-total">
                                            <th>Shipping</th>
                                            <th>$<?php echo e($Shipping); ?>

                                                <input type="hidden" name="Shipping" value="<?php echo e($Shipping); ?>">
                                            </th>
                                        </tr>
                                        <tr class="order-total">
                                            <th>Coupon Discuont (0%)</th>
                                            <th>$<?php echo e($cupon_discount); ?>

                                                <input type="hidden" name="cupon_discount"
                                                    value="<?php echo e($cupon_discount); ?>">
                                            </th>
                                        </tr>
                                        <tr class="order-total">
                                            <th>Total</th>
                                            <th>$<?php echo e($total_amount_show); ?>

                                                <input type="hidden" name="total_amount_show"
                                                    value="<?php echo e($total_amount_show); ?>">
                                            </th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <div class="payment-method">
                                <div class="pm-item">
                                    <input type="radio" name="payment_type" id="two" checked value="1">
                                    <label for="two">Cash on delievery</label>
                                </div>
                                <div class="pm-item">
                                    <input type="radio" name="payment_type" id="three" value="2">
                                    <label for="three">Credit card</label>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="site-btn btn-full">Place Order</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>
<script type="text/javascript">
$(document).ready(function() {
    $('#country').change(function() {
        var division_id = $(this).val();
        // alert(division_id);

        // Axios SetUp Start
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });


        $.ajax({
            type: 'POST',
            url: '/get/districts',
            data: {
                division_id: division_id
            },
            success: function(data) {
                // alert(data);
                // $( "#company_upazilla" ).html(data);
                $('#district').html(data);
            }
        });




    })

});
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim\Desktop\Desktop\josim\blog\resources\views/frontend/procestocheckout.blade.php ENDPATH**/ ?>