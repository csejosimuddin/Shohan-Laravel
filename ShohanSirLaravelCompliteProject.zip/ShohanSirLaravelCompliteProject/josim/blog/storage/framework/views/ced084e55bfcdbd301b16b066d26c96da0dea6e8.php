<?php $__env->startSection('title','HomePAge'); ?>
<?php $__env->startSection('content'); ?>



<section class="hero-section set-bg" data-setbg="<?php echo e(asset('/frontend_assets/img/bg.jpg')); ?>">
    <div class="hero-slider owl-carousel">
        <div class="hs-item">
            <div class="hs-left"><img
                    src="<?php echo e(asset('/frontend_assets/img/xslider-img.png.pagespeed.ic.nSv9moMGP4.png')); ?>" alt=""></div>
            <div class="hs-right">
                <div class="hs-content">
                    <div class="price">from $19.90</div>
                    <h2><span>2018</span> <br>summer collection</h2>
                    <a href="#" class="site-btn">Shop NOW!</a>
                </div>
            </div>
        </div>
        <div class="hs-item">
            <div class="hs-left"><img
                    src="<?php echo e(asset('/frontend_assets/img/xslider-img.png.pagespeed.ic.nSv9moMGP4.png')); ?>" alt=""></div>
            <div class="hs-right">
                <div class="hs-content">
                    <div class="price">from $19.90</div>
                    <h2><span>2018</span> <br>summer collection</h2>
                    <a href="#" class="site-btn">Shop NOW!</a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="intro-section spad pb-0">
    <div class="section-title">
        <h2>pemium products</h2>
        <p>We recommend</p>
    </div>
    <div class="intro-slider">
        <ul class="slidee">

            <?php $__currentLoopData = $all_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li>
                <div class="intro-item">
                    <figure>
                    <a href="<?php echo e(url('product/Details')); ?>/<?php echo e($all_product->id); ?>" class="site-btn btn-line">
                        
                        <img src="<?php echo e(asset('uploads/product_photos')); ?>/<?php echo e($all_product->Product_image); ?>" alt="#">
                        </a>
                    </figure>
                    <div class="product-info">
                        <h5><?php echo e($all_product->Product_Name); ?></h5>
                        <p>$<?php echo e($all_product->Product_Price); ?></p>
                        <a href="<?php echo e(url('product/Details')); ?>/<?php echo e($all_product->id); ?>" class="site-btn btn-line">ADD TO CART</a>
                        
                    </div>
                </div>
            </li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
    </div>
    <div class="container">
        <div class="scrollbar">
            <div class="handle">
                <div class="mousearea"></div>
            </div>
        </div>
    </div>
</section>


<div class="featured-section spad">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="featured-item">
                    <img src="<?php echo e(asset('/frontend_assets/img/featured/xfeatured-1.jpg.pagespeed.ic.PGultcpWZa.jpg')); ?>"
                        alt="">
                    <a href="#" class="site-btn">see more</a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="featured-item mb-0">
                    <img src="<?php echo e(asset('/frontend_assets/img/featured/xfeatured-2.jpg.pagespeed.ic.vNHk6zB1n9.jpg')); ?>"
                        alt="">
                    <a href="#" class="site-btn">see more</a>
                </div>
            </div>
        </div>
    </div>
</div>


<section class="product-section spad">
    <div class="container">
        <ul class="product-filter controls">
            <li class="control" data-filter="all">All</li>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li class="control" data-filter=".filterjosim<?php echo e($category->id); ?>"><?php echo e($category->category_id); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="row" id="product-filter">
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mix col-lg-3 col-md-6 all filterjosim<?php echo e($product->category_p_id); ?>">
                <div class="product-item">
                    <figure>
                    <img src="<?php echo e(asset('uploads/product_photos')); ?>/<?php echo e($product->Product_image); ?>" alt="#">
                        <div class="pi-meta">
                            <div class="pi-m-left">
                                <img src="<?php echo e(asset('/frontend_assets/img/icons/xeye.png.pagespeed.ic.vB4F1dJ6Q-.png')); ?>"
                                    alt="">
                                <p><?php echo e($product->Product_Name); ?></p>
                            </div>
                            <div class="pi-m-right">
                                <img src="<?php echo e(asset('/frontend_assets/img/icons/xheart.png.pagespeed.ic.l61UmCCZiL.png')); ?>"
                                    alt="">
                                <p><?php echo e($product->Product_Description); ?></p>
                            </div>
                        </div>
                    </figure>
                    <div class="product-info">
                        <h6><?php echo e($product->Product_Alert_Quentity); ?></h6>
                        <p>$<?php echo e($product->Product_Price); ?></p>
                        <a href="#" class="site-btn btn-line">ADD TO CART</a>
                    </div>
                </div>
            </div>
         
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<section>
<div class="container">
<div class="row">
<div class="col-lg-12">
<div class="Heading">





</div>
</div>
</div>
</div>
</section>

<section class="blog-section spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="featured-item">
                    <img src="img/featured/featured-3.jpg" alt="">
                    <a href="#" class="site-btn">see more</a>
                </div>
            </div>
            <div class="col-lg-7">
                <h4 class="bgs-title">from the blog</h4>
                <div class="blog-item">
                    <div class="bi-thumb">
                        <img src="img/blog-thumb/1.jpg" alt="">
                    </div>
                    <div class="bi-content">
                        <h5>10 tips to dress like a queen</h5>
                        <div class="bi-meta">July 02, 2018 | By maria deloreen</div>
                        <a href="#" class="readmore">Read More</a>
                    </div>
                </div>
                <div class="blog-item">
                    <div class="bi-thumb">
                        <img src="img/blog-thumb/2.jpg" alt="">
                    </div>
                    <div class="bi-content">
                        <h5>Fashion Outlet products</h5>
                        <div class="bi-meta">July 02, 2018 | By Jessica Smith</div>
                        <a href="#" class="readmore">Read More</a>
                    </div>
                </div>
                <div class="blog-item">
                    <div class="bi-thumb">
                        <img src="img/blog-thumb/3.jpg" alt="">
                    </div>
                    <div class="bi-content">
                        <h5>the little black dress just for you</h5>
                        <div class="bi-meta">July 02, 2018 | By maria deloreen</div>
                        <a href="#" class="readmore">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim\Desktop\Desktop\josim\blog\resources\views/frontend/index.blade.php ENDPATH**/ ?>