<?php $__env->startSection('content'); ?>


<div class="container">
<div class="row">
<div class="col-lg-12 p-0">
<h2 class="bg-primary text-center" style="color: #fff;" >Customir Product Parches List</h2>
</div>

<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">Total Amount</th>
      <th scope="col">payment Type</th>
      <th scope="col">Payment Status</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($order->total_amount_show); ?></td>
      <td><?php echo e(($order->payment_type == 1) ? "Cash On Delivery":"Card Payment"); ?></td>
      <td><?php echo e(($order->payment_status == 1) ? "Pending":"success"); ?></td>
      <td>
      <a href="<?php echo e(url('order/details')); ?>/<?php echo e($order->id); ?>">View</a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>



</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim\Desktop\Desktop\josim\blog\resources\views/frontend/CustDash/view.blade.php ENDPATH**/ ?>