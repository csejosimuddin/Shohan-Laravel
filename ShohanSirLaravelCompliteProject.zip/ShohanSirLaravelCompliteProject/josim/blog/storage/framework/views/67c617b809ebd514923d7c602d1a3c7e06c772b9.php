<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row">
        <div class="col-lg-8 offset-2">

            <div class="card-body">

            <?php if(App\review::where('product_id', $product_id)->exists()): ?>

        echo "আপনি একবার রিভিউ দিয়েছেন আর না বস";
            <?php else: ?>
                <form method="post" action="<?php echo e(url('submit/review/insert')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="hidden" name="order_history_id" value="<?php echo e($order_history_id); ?>">
                        <input type="hidden" name="product_id" value="<?php echo e($product_id); ?>">
                        <label for="one">Your Comment</label>
                        <textarea class="form-control" name="Comment" rows="5"></textarea>

                    </div>

                    <div class="form-group">
                        <label for="one2">Your Comment</label>
                        <input class="form-control" type="range" name="points" min="1" max="5" step="1"
                            value="1"></input>

                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>

                </form>

                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim\Desktop\Desktop\josim\blog\resources\views/frontend/CustDash/review.blade.php ENDPATH**/ ?>