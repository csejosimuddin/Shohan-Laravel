<?php $__env->startSection('content'); ?>


<div class="container">
	<div class="row">
		<div class="col-6 offset-3">
			<div class="card mb-3">
				<div class="card-header">
					set/Change Password
					
				</div>
				<div class="card-body">
					<?php if($errors->all()): ?>
					<div class="alert alert-danger" role="alert">
						
				
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<?php endif; ?>

					<!-- password Change করার জনে -->
			 <form action="<?php echo e(url('Change/password')); ?>" method="post">
               <?php echo csrf_field(); ?>

               <div class="form-group">

               	                  <label>Old Password</label>
                  <input type="password" class="form-control" name="oldpassword" placeholder="Enter Your Password" value="<?php echo e(old('newpassword')); ?>">
                  <label>New Password</label>
                  <input type="password" class="form-control" name="newpassword" placeholder="Enter Your Password" value="<?php echo e(old('newpassword')); ?>">

                  <label>Confirm Password</label>
                  <input type="password" class="form-control" name="confirmpassword" placeholder="Enter Your Confirm Password" value="<?php echo e(old('confirmpassword')); ?>">

               </div>
               
              
          <button type="submit" class="btn btn-info">Change Password</button>
            </form>	
					
				</div>
				
			</div>
			
		</div>
		
	</div>
	
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim\Desktop\Desktop\josim\blog\resources\views/frontend/CustDash/passwordChange.blade.php ENDPATH**/ ?>